"use client";

import {
  DeleteOutlined,
  EditOutlined,
  EyeOutlined,
  PlusOutlined,
  ReloadOutlined,
  SearchOutlined,
} from "@ant-design/icons";
import {
  Button,
  Card,
  DatePicker,
  Descriptions,
  Grid,
  Input,
  Modal,
  Select,
  Space,
  Spin,
  Table,
  Tooltip,
  Typography,
} from "antd";
import type { ColumnsType } from "antd/es/table";
import dayjs, { type Dayjs } from "dayjs";
import JSZip from "jszip";
import { Check, CircleHelp, Clock3, FileText, UserRound, X } from "lucide-react";
import { useSession } from "next-auth/react";
import { useEffect, useMemo, useRef, useState } from "react";
import { mutate } from "swr";

import BtnConfirm from "@/lib/components/shared/BtnConfirm";
import { baseFilter } from "@/lib/core/configs/appConst";
import TitlePage from "@/lib/core/layout/components/TitlePage";
import { FormatDate } from "@/lib/core/utils/myFormat";
import { useAdminContext } from "@/lib/stored";
import documentApi from "@/services/api/document/documentApi";
import documentTypeApi from "@/services/api/document/documentTypeApi";
import type {
  IDocumentResponse,
  IDocumentTypeResponse,
} from "@/services/api/document/IDocument";

import AddEditDocument from "./addEdit";

const { RangePicker } = DatePicker;
const { Search } = Input;
const canManage = (roleId?: number) => [1, 2].includes(roleId ?? 0);

type DocumentMetadata = IDocumentResponse & {
  Code?: string;
  PageCount?: number;
  Pages?: number;
  PostedDate?: string;
  PublishedDate?: string;
  ApprovedBy?: string;
  ApprovedDate?: string;
  Status?: number;
  StatusName?: string;
};

const getFileUrl = (value: unknown): string | undefined => {
  const item = Array.isArray(value) ? value[0] : value;
  if (typeof item === "string") return item.split("|")[0]?.trim() || undefined;
  if (item && typeof item === "object") {
    const file = item as { url?: string; Path?: string };
    return file.url ?? file.Path;
  }
  return undefined;
};

const readPageCount = async (document: DocumentMetadata): Promise<number | undefined> => {
  if (document.PageCount ?? document.Pages) return document.PageCount ?? document.Pages;
  const url = getFileUrl(document.PdfFile) ?? getFileUrl(document.DocFile);
  if (!url) return undefined;

  try {
    const response = await fetch(url);
    if (!response.ok) return undefined;
    const bytes = await response.arrayBuffer();
    if (/\.pdf(?:$|[?#])/i.test(url) || getFileUrl(document.PdfFile) === url) {
      const pdfText = new TextDecoder("latin1").decode(bytes);
      const pageTreeCounts = [...pdfText.matchAll(/\/Type\s*\/Pages\b[\s\S]{0,2048}?\/Count\s+(\d+)/g)]
        .map((match) => Number(match[1]));
      if (pageTreeCounts.length) return Math.max(...pageTreeCounts);
      const pageObjects = pdfText.match(/\/Type\s*\/Page\b/g)?.length;
      return pageObjects || undefined;
    }

    if (/\.docx(?:$|[?#])/i.test(url)) {
      const zip = await JSZip.loadAsync(bytes);
      const xml = await zip.file("word/document.xml")?.async("string");
      if (!xml) return undefined;
      const renderedBreaks = xml.match(/<(?:\w+:)?lastRenderedPageBreak\b/g)?.length ?? 0;
      const explicitBreaks = xml.match(/<(?:\w+:)?br\b[^>]*(?:\w+:)?type=["']page["'][^>]*\/?\s*>/g)?.length ?? 0;
      const breaks = Math.max(renderedBreaks, explicitBreaks);
      return breaks ? breaks + 1 : undefined;
    }
  } catch {
    // File hosts can disallow browser access (CORS); keep the count empty then.
  }
  return undefined;
};

const statusPresentation = (status?: string) => {
  const value = status?.toLocaleLowerCase("vi") ?? "";
  if (value.includes("duyệt") && !value.includes("chờ")) return { className: "approved", Icon: Check };
  if (value.includes("từ chối") || value.includes("hủy")) return { className: "rejected", Icon: X };
  if (value.includes("chờ") || value.includes("chưa")) return { className: "pending", Icon: Clock3 };
  return { className: "unknown", Icon: CircleHelp };
};

const DocumentPage = () => {
  const { data: session } = useSession();
  const { smallScreen } = useAdminContext();
  const screens = Grid.useBreakpoint();
  const isWideLayout = Boolean(screens.lg);
  const isFullTable = Boolean(screens.xl);
  const [openModal, setOpenModal] = useState(false);
  const [selected, setSelected] = useState<IDocumentResponse>();
  const [viewing, setViewing] = useState<DocumentMetadata>();
  const [keyword, setKeyword] = useState("");
  const [range, setRange] = useState<[Dayjs | null, Dayjs | null] | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<string>();
  const [selectedType, setSelectedType] = useState<number>();
  const [searchText, setSearchText] = useState("");
  const [pageCounts, setPageCounts] = useState<Record<number, number>>({});
  const requestedPageCounts = useRef(new Set<number>());
  const [tablePage, setTablePage] = useState(1);
  const [tablePageSize, setTablePageSize] = useState(10);
  const isAdmin = canManage(session?.user?.RoleId);

  const { data: types, isLoading: loadingTypes } = documentTypeApi.useGet(baseFilter);
  const { data: docs, isLoading: loadingDocuments } = documentApi.useGet({
    pageIndex: 1,
    pageSize: 1000,
  });
  const categories = types?.data ?? [];
  const documents = (docs?.data ?? []) as DocumentMetadata[];

  const statusOptions = useMemo(() => {
    const names = new Set(
      documents.map((document) => document.StatusName?.trim()).filter(Boolean) as string[]
    );
    ["Đã duyệt", "Chờ duyệt", "Từ chối"].forEach((name) => {
      if (![...names].some((value) => value.toLocaleLowerCase("vi") === name.toLocaleLowerCase("vi"))) {
        names.add(name);
      }
    });
    return [...names].map((name) => ({ label: name, value: name }));
  }, [documents]);

  const filteredDocuments = useMemo(() => {
    const normalizedSearch = searchText.trim().toLocaleLowerCase("vi");
    return documents.filter((document) => {
      const documentDate = dayjs(document.PostedDate ?? document.PublishedDate ?? document.CreatedDate);
      const matchesSearch =
        !normalizedSearch ||
        [document.Code, document.Id?.toString(), document.Name, document.Note]
          .filter(Boolean)
          .some((value) => value?.toLocaleLowerCase("vi").includes(normalizedSearch));
      const matchesType = selectedType === undefined || document.DocumentTypeId === selectedType;
      const matchesStatus =
        !selectedStatus ||
        (document.StatusName ?? "").toLocaleLowerCase("vi") === selectedStatus.toLocaleLowerCase("vi");
      const matchesStart = !range?.[0] || !documentDate.isValid() || !documentDate.isBefore(range[0], "day");
      const matchesEnd = !range?.[1] || !documentDate.isValid() || !documentDate.isAfter(range[1], "day");
      return matchesSearch && matchesType && matchesStatus && matchesStart && matchesEnd;
    });
  }, [documents, range, searchText, selectedStatus, selectedType]);

  useEffect(() => {
    let cancelled = false;
    const visibleDocuments = filteredDocuments.slice((tablePage - 1) * tablePageSize, tablePage * tablePageSize);
    const missingCounts = visibleDocuments.filter((document) =>
      document.Id && pageCounts[document.Id] === undefined && !requestedPageCounts.current.has(document.Id) && (document.PdfFile || document.DocFile)
    );
    if (!missingCounts.length) return;
    missingCounts.forEach((document) => requestedPageCounts.current.add(document.Id as number));
    Promise.all(missingCounts.map(async (document) => ({
      id: document.Id as number,
      count: await readPageCount(document),
    }))).then((results) => {
      if (cancelled) return;
      setPageCounts((current) => {
        const next = { ...current };
        results.forEach(({ id, count }) => { if (count !== undefined) next[id] = count; });
        return next;
      });
    });
    return () => { cancelled = true; };
  }, [filteredDocuments, pageCounts, tablePage, tablePageSize]);

  const openAdd = () => {
    setSelected(undefined);
    setOpenModal(true);
  };

  const resetFilters = () => {
    setRange(null);
    setSelectedStatus(undefined);
    setSelectedType(undefined);
    setKeyword("");
    setSearchText("");
  };

  const columns: ColumnsType<DocumentMetadata> = [
    {
      title: "Mã",
      key: "Code",
      width: screens.xl ? 90 : isWideLayout ? 70 : 55,
      render: (_, document) => document.Code || (document.Id ? String(document.Id) : "—"),
    },
    {
      title: "Tên văn bản",
      dataIndex: "Name",
      key: "Name",
      width: screens.xl ? 450 : isWideLayout ? 255 : 155,
      ellipsis: true,
      render: (name: string) => (
        <Typography.Text className="document-table-name" ellipsis={{ tooltip: name }}>
          {name || "—"}
        </Typography.Text>
      ),
    },
    {
      title: "Danh mục",
      dataIndex: "DocumentTypeId",
      key: "DocumentTypeId",
      width: screens.xl ? 180 : isWideLayout ? 130 : 95,
      ellipsis: true,
      render: (id: number) => categories.find((type) => type.Id === id)?.Name ?? "—",
    },
    {
      title: "Số trang",
      key: "PageCount",
      width: screens.xl ? 80 : isWideLayout ? 55 : 50,
      align: "center",
      render: (_, document) => {
        const count = document.PageCount ?? document.Pages ?? (document.Id ? pageCounts[document.Id] : undefined);
        return count ? <span className="document-page-count"><FileText size={14} />{count}</span> : "—";
      },
    },
    {
      title: "Ngày đăng",
      key: "PostedDate",
      width: screens.xl ? 130 : isWideLayout ? 95 : 76,
      render: (_, document) =>
        FormatDate(document.PostedDate ?? document.PublishedDate ?? document.CreatedDate) || "—",
    },
    {
      title: "Người duyệt",
      key: "ApprovedBy",
      width: screens.xl ? 170 : isWideLayout ? 125 : 100,
      render: (_, document) => (
        document.ApprovedBy ? (
          <div className="document-approver">
            <span className="document-approver-name"><UserRound size={14} />{document.ApprovedBy}</span>
            {document.ApprovedDate && <span className="document-approver-date">{FormatDate(document.ApprovedDate)}</span>}
          </div>
        ) : <Typography.Text type="secondary">—</Typography.Text>
      ),
    },
    {
      title: "Trạng thái",
      dataIndex: "StatusName",
      key: "StatusName",
      width: screens.xl ? 120 : isWideLayout ? 90 : 75,
      render: (status?: string) => {
        if (!status) return <Typography.Text type="secondary">—</Typography.Text>;
        const { className, Icon } = statusPresentation(status);
        return <span className={`document-status ${className}`}><Icon size={13} />{status}</span>;
      },
    },
    {
      title: "Chức năng",
      key: "actions",
      width: screens.xl ? 120 : isWideLayout ? 100 : 95,
      align: "center",
      render: (_: unknown, document: DocumentMetadata) => (
        <Space size={0}>
          <Tooltip title="Xem văn bản">
            <Button
              type="text"
              size="small"
              aria-label={`Xem ${document.Name}`}
              icon={<EyeOutlined />}
              onClick={() => setViewing(document)}
            />
          </Tooltip>
          <Tooltip title={isAdmin ? "Chỉnh sửa" : "Bạn không có quyền chỉnh sửa"}>
            <Button
              type="text"
              size="small"
              disabled={!isAdmin}
              aria-label={`Sửa ${document.Name}`}
              icon={<EditOutlined />}
              onClick={() => {
                setSelected(document);
                setOpenModal(true);
              }}
            />
          </Tooltip>
          <Tooltip title={isAdmin ? "Xóa văn bản" : "Bạn không có quyền xóa"}>
            <span>
              {isAdmin ? (
                <BtnConfirm
                  type="icon"
                  size="small"
                  icon={<DeleteOutlined />}
                  danger
                  title="Xóa văn bản này?"
                  onOkClick={async () => {
                    if (document.Id) {
                      await documentApi.delete(document.Id);
                      await mutate(documentApi.mutateKey);
                    }
                  }}
                />
              ) : (
                <Button type="text" size="small" danger disabled icon={<DeleteOutlined />} />
              )}
            </span>
          </Tooltip>
        </Space>
      ),
    },
  ];

  return (
    <div className="document-management-page">
      <div className="document-management-heading">
        <div className="document-management-breadcrumb">
          <Typography.Text type="secondary">Danh sách văn bản</Typography.Text>
          <span>/</span>
          <Typography.Text>Hợp đồng</Typography.Text>
        </div>
        <TitlePage title="Hợp đồng" />
      </div>

      <Card className="document-management-card" bordered={false}>
        <div className="document-filter-row">
          <div className="document-filter-item document-filter-date">
            <label>Thời gian</label>
            <RangePicker
              value={range}
              onChange={(value) => setRange(value as [Dayjs | null, Dayjs | null] | null)}
              format="DD/MM/YYYY"
              placeholder={["Từ ngày", "Đến ngày"]}
              allowEmpty={[true, true]}
            />
          </div>
          <div className="document-filter-item document-filter-status">
            <label>Trạng thái</label>
            <Select
              allowClear
              value={selectedStatus}
              onChange={setSelectedStatus}
              placeholder="Chọn"
              options={statusOptions}
            />
          </div>
          <div className="document-filter-item document-filter-type">
            <label>Tài liệu</label>
            <Select
              allowClear
              value={selectedType}
              onChange={setSelectedType}
              placeholder="Chọn"
              options={categories.map((type: IDocumentTypeResponse) => ({
                label: type.Name,
                value: type.Id,
              }))}
            />
          </div>
          <Search
            value={keyword}
            onChange={(event) => setKeyword(event.target.value)}
            onSearch={(value) => setSearchText(value)}
            placeholder="Tìm kiếm văn bản"
            allowClear
            enterButton={<><SearchOutlined /> Tìm kiếm</>}
            style={{ minWidth: smallScreen ? "100%" : 280, flex: 1 }}
          />
          <Button
            title="Đặt lại bộ lọc"
            aria-label="Đặt lại bộ lọc"
            icon={<ReloadOutlined />}
            shape="circle"
            onClick={resetFilters}
          />
        </div>

        <div className="document-table-toolbar">
          <Tooltip title={isAdmin ? "" : "Bạn không có quyền thêm văn bản"}>
            <Button type="primary" icon={<PlusOutlined />} onClick={openAdd} disabled={!isAdmin}>
              Thêm mới
            </Button>
          </Tooltip>
        </div>

        {loadingTypes ? (
          <div className="document-table-loading"><Spin /></div>
        ) : (
          <Table<DocumentMetadata>
            rowKey={(document) => String(document.Id)}
            columns={columns}
            dataSource={filteredDocuments}
            loading={loadingDocuments}
            size="middle"
            scroll={{ x: isFullTable ? 1320 : isWideLayout ? 905 : 690 }}
            onChange={(pagination) => {
              setTablePage(pagination.current ?? 1);
              setTablePageSize(pagination.pageSize ?? 10);
            }}
            pagination={{
              defaultPageSize: 10,
              showSizeChanger: true,
              pageSizeOptions: [10, 20, 50],
              showTotal: (total, range) => `${range[0]}–${range[1]} trong ${total} dòng`,
              showQuickJumper: false,
            }}
          />
        )}
      </Card>

      <AddEditDocument
        isOpen={openModal}
        onOpenChange={(isOpen) => {
          setOpenModal(isOpen);
          if (!isOpen) setSelected(undefined);
        }}
        types={categories}
        model={selected}
      />

      <Modal
        title="Thông tin văn bản"
        open={Boolean(viewing)}
        onCancel={() => setViewing(undefined)}
        footer={
          <Space>
            {viewing?.PdfFile && (
              <Button href={String(viewing.PdfFile)} target="_blank" rel="noreferrer">
                Mở PDF
              </Button>
            )}
            {viewing?.DocFile && (
              <Button href={String(viewing.DocFile)} target="_blank" rel="noreferrer">
                Mở Word
              </Button>
            )}
            <Button type="primary" onClick={() => setViewing(undefined)}>Đóng</Button>
          </Space>
        }
      >
        {viewing && (
          <Descriptions column={1} bordered size="small">
            <Descriptions.Item label="Mã">{viewing.Code || (viewing.Id ? String(viewing.Id) : "—")}</Descriptions.Item>
            <Descriptions.Item label="Tên văn bản">{viewing.Name || "—"}</Descriptions.Item>
            <Descriptions.Item label="Danh mục">
              {categories.find((type) => type.Id === viewing.DocumentTypeId)?.Name ?? "—"}
            </Descriptions.Item>
            <Descriptions.Item label="Mô tả">{viewing.Note || "—"}</Descriptions.Item>
            <Descriptions.Item label="Ngày đăng">
              {FormatDate(viewing.PostedDate ?? viewing.PublishedDate ?? viewing.CreatedDate) || "—"}
            </Descriptions.Item>
            <Descriptions.Item label="Trạng thái">{viewing.StatusName || "—"}</Descriptions.Item>
          </Descriptions>
        )}
      </Modal>
    </div>
  );
};

export default DocumentPage;
