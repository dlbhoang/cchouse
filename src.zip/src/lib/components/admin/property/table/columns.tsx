/* eslint-disable no-nested-ternary */
import { sendGTMEvent } from "@next/third-parties/google";
import { Avatar, Space, Tag, Tooltip, Typography } from "antd";
import { ColumnsType } from "antd/lib/table";
import {
  CopyIcon,
  HistoryIcon,
  ImageIcon,
  ShoppingCartIcon,
  Trash2Icon,
  VideoIcon,
} from "lucide-react";
import { ReactNode } from "react";
import { mutate } from "swr";
import { Button } from "@/components/ui/button";
import CopyButton from "@/components/ui/button/copy-btn";
import CustomerPhoneButton from "@/lib/components/shared/Button/customer-phone";
import RenderArea from "@/lib/components/shared/CustomRender/RenderArea";
import NoteModal from "@/lib/components/shared/noteModal";
import { appConst } from "@/lib/core/configs/appConst";
import { ETransType } from "@/lib/core/enum";
import { CopyProp } from "@/lib/core/utils/actionCopy";
import { IPropResponse } from "@/lib/interfaces/Property/IProp";
import { IPropCompare } from "@/lib/interfaces/Property/IPropCompare";
import propertyApi from "@/services/api/property/propertyApi";
import userAdminApi from "@/services/api/userAdmin/userAdminApi";
import { IUserLogged } from "@/types/next-auth";

const { Text } = Typography;

const AlleyInfo = ({ record }: { record: IPropResponse }) => {
  return (
    <Space direction="vertical">
      {record.PropAddress.DistanceToFont > 0 && (
        <span>{`Cách MT: ${record.PropAddress.DistanceToFont} m`}</span>
      )}
      <span>{record.PropAddress.AlleyTurns} lần rẽ</span>
      {record.PropAddress?.AlleyValues?.map((e, idx) => (
        <Text key={idx.toString()}>
          Lần rẽ {idx + 1}: {e}m
        </Text>
      ))}
    </Space>
  );
};

type Props = {
  userSession?: IUserLogged;
  listCompare: IPropCompare[];
  onCompare: (item: IPropCompare) => void;
  handleOpenQU: (id: number) => void;
  handleOpenPreview: (id: number) => void;
  handleOpenImages: (id: number) => void;
  handleOpenVideo: (val: string) => void;
  handleOpenContact: (id: number) => void;
  handleOpenHistory: (id: number) => void;
  handleOpenDetail: (id: number) => void;
};

const columns = ({
  userSession,
  listCompare,
  onCompare,
  handleOpenImages,
  handleOpenVideo,
  handleOpenContact,
  handleOpenHistory,
  handleOpenDetail,
}: // eslint-disable-next-line sonarjs/cognitive-complexity
Props): ColumnsType<IPropResponse> => {
  const detailLink = (id: number, children: ReactNode) => (
    <span
      className="cursor-pointer hover:text-blue-500"
      onClick={() => handleOpenDetail(id)}
    >
      {children}
    </span>
  );

  return [
    {
      title: "Mã",
      dataIndex: "Id",
      align: "center",
      render(value, record) {
        return (
          <Space direction="vertical" align="center">
            {detailLink(record.Id, <Text>{value}</Text>)}
            <Tooltip title="Lịch sử">
              <Button
                variant="ghost"
                size="icon-sm"
                className="rounded-full"
                onClick={() => handleOpenHistory(record.Id)}
                style={{
                  color: appConst.PROP_STATUS_COLORS[record.Status - 1],
                }}
              >
                <HistoryIcon className="size-4" />
              </Button>
            </Tooltip>
          </Space>
        );
      },
    },
    {
      title: "Giá",
      dataIndex: "DisplayPrice",
      render(value, record) {
        return (
          <Space direction="vertical">
            {detailLink(
              record.Id,
              <Text style={{ whiteSpace: "nowrap" }}>{value}</Text>
            )}
            <Text
              type="secondary"
              style={{ fontSize: 12, whiteSpace: "nowrap" }}
            >
              {record?.PricePerSquareMeter}
            </Text>
            {record.IsMonopoly && <Tag color="orange">Độc quyền</Tag>}
          </Space>
        );
      },
    },
    {
      title: "Địa chỉ",
      dataIndex: ["PropAddress", "AddressNumber"],
      render(value, record) {
        const { LandNumber, MapNumber } = record.PropAddress;
        return (
          <Space direction="vertical">
            {LandNumber ? (
              detailLink(
                record.Id,
                <>
                  <Text
                    style={{ whiteSpace: "nowrap" }}
                  >{`Thửa đất: ${LandNumber}`}</Text>
                  <br />
                  <Text style={{ whiteSpace: "nowrap" }}>
                    {`Tờ bản đồ: ${MapNumber}`}
                  </Text>
                </>
              )
            ) : (
              detailLink(
                record.Id,
                <>
                  <Text style={{ whiteSpace: "nowrap" }}>{`${
                    record.PropAddress.AddressNumber
                  } ${
                    record.PropAddress.SubAddressName
                      ? `(${record.PropAddress.SubAddressName})`
                      : ""
                  } ${record.PropAddress.StreetName ?? ""}`}</Text>
                  <br />
                  {record.PropAddress.OldAddressNumber && (
                    <Text type="secondary" style={{ fontSize: 12 }}>
                      Số cũ: {record.PropAddress.OldAddressNumber}
                    </Text>
                  )}
                  {record.PropAddress.OldStreetName && (
                    <>
                      <br />
                      <Text type="secondary" style={{ fontSize: 12 }}>
                        ({record.PropAddress.OldStreetName})
                      </Text>
                    </>
                  )}
                </>
              )
            )}
            {record.Note && (
              <NoteModal
                  readOnly
                title={`Mã BĐS: ${record?.Id}`}
                historyId={record.Id}
                value={record.Note}
                handleChange={async (note) => {
                  await propertyApi.quickUpdate({
                    Id: record?.Id,
                    Note: note ?? "",
                  });

                  mutate(propertyApi.mutateKey);
                }}
              />
            )}
          </Space>
        );
      },
    },
    {
      title: "Xã phường quận",
      dataIndex: ["PropAddress", "WardName"],
      render: (value, record) => {
        const oldParts = [
          record.PropAddress.OldWardName,
          record.PropAddress.OldDistrictName,
        ].filter(Boolean);

        return detailLink(
          record.Id,
          <>
            <Text style={{ whiteSpace: "nowrap" }}>
              {[
                value,
                record.PropAddress.DistrictName,
              ]
                .filter(Boolean)
                .join(", ")}
            </Text>
            {record.PropAddress.ProvinceName && (
              <>
                <br />
                <Text type="secondary" style={{ whiteSpace: "nowrap" }}>
                  {record.PropAddress.ProvinceName}
                </Text>
              </>
            )}
            {oldParts.length > 0 && (
              <>
                <br />
                <Text
                  style={{
                    color: "var(--Text-Muted, #737373)",
                    fontFamily: "Inter",
                    fontSize: "var(--Font-sizes-text-xs, 12px)",
                    fontStyle: "normal",
                    fontWeight: 400,
                    lineHeight: "var(--Line-height-text-xs, 16px)",
                    whiteSpace: "nowrap",
                  }}
                >
                  {oldParts.join(", ")} (cũ)
                </Text>
              </>
            )}
          </>
        );
      },
    },
    {
      title: "Loại BĐS",
      dataIndex: ["PropAddress", "PropTypeName"],
      render: (value, record) =>
        detailLink(
          record.Id,
          <Space direction="vertical">
            <Text>{value}</Text>
            {record.PropAddress?.PropName && (
              <Tag color="processing">{record.PropAddress?.PropName}</Tag>
            )}
          </Space>
        ),
    },
    {
      title: "Kết cấu",
      dataIndex: "CustomDisplayStructures",
      render(value, record) {
        return (
          <Space direction="vertical">
            {detailLink(record.Id, <Text>{value?.toString()}</Text>)}
            <Space>
              {record.MainImage && (
                <Button
                  type="button"
                  size="icon-sm"
                  className="rounded-full"
                  onClick={() => {
                    handleOpenImages(record.Id);
                  }}
                >
                  <ImageIcon />
                </Button>
              )}
              {record.Video && (
                <Button
                  type="button"
                  size="icon-sm"
                  className="rounded-full"
                  onClick={() => {
                    handleOpenVideo(record.Video);
                  }}
                >
                  <VideoIcon />
                </Button>
              )}
            </Space>
          </Space>
        );
      },
    },
    {
      title: "Diện tích",
      dataIndex: "Area",
      render(value, record) {
        return (
          <Space direction="vertical">
            <RenderArea
              title="DTTT: "
              area={value}
              length={record.Length}
              width={record.Width}
              backSide={record.BackSide}
            />
            {record.PropAddress.AreaLegal > 0 &&
              record.TransType === ETransType.sell && (
                <RenderArea
                  title="DTCN: "
                  area={record.PropAddress.AreaLegal}
                  length={record.PropAddress.LengthLegal}
                  width={record.PropAddress.WidthLegal}
                  backSide={record.PropAddress.BackSideLegal}
                />
              )}
            {record.FloorArea > 0 && (
              <RenderArea title="DT sàn: " area={record.FloorArea} />
            )}
          </Space>
        );
      },
    },
    {
      title: "Vị trí",
      dataIndex: ["PropAddress", "LocationName"],
      render(value, record) {
        return detailLink(
          record.Id,
          <Space direction="vertical">
            <Text>
              {value} {record.PropAddress.IsOneWay && "(1 chiều)"}{" "}
              {record.PropAddress.AlleyTurns === 1 &&
                record.PropAddress.AlleyValues?.length === 1 &&
                `${record.PropAddress.AlleyValues[0] ?? 0}m`}
            </Text>
            {record.PropAddress.StreetWidth > 0 && (
              <Text>Độ rộng: {record.PropAddress.StreetWidth} m</Text>
            )}
            {record.PropAddress.AlleyTurns > 1 && <AlleyInfo record={record} />}
            {record.PropAddress.LocationFeatureName && (
              <Tag color="#000000" style={{ color: "#fff", border: "none" }}>
                {record.PropAddress.LocationFeatureName}
              </Tag>
            )}
          </Space>
        );
      },
    },
    {
      title: "Hướng",
      dataIndex: ["PropAddress", "DirectionName"],
    },
    {
      title: "SĐT",
      align: "center",
      render: (value, record) => {
        const logo = record.CustomerLogo ? (
          <Avatar src={record.CustomerLogo?.toString()} size={"small"} />
        ) : undefined;
        return record.IsHidePhone &&
          record.UserAdminId !== userSession?.Id &&
          userSession?.RoleName !== "Admin" ? (
          <Tag>Ẩn SĐT</Tag>
        ) : (
          <Tooltip title={record.CustomerTypeName}>
            <Space direction="vertical">
              <CustomerPhoneButton
                typeName={record.CustomerTypeName}
                icon={logo}
                onClick={() => handleOpenContact(record.Id)}
              />

              {record.IsHidePhone && <Tag>Ẩn SĐT</Tag>}
            </Space>
          </Tooltip>
        );
      },
    },
    {
      key: "Action",
      title: "Hành động",
      dataIndex: "CreatedDate",
      render: (value, record) => (
        <Space direction="vertical">
          {record.StatusName === "Chờ xoá" ? (
            [1, 2].includes(userSession?.RoleId ?? 0) && (
              <Tooltip title="Xoá">
                <Button
                  size="sm"
                  variant="destructive"
                  className="rounded-full"
                  onClick={async () => {
                    await propertyApi.delete(record.Id);
                    mutate(propertyApi.mutateKey);
                  }}
                >
                  <Trash2Icon />
                </Button>
              </Tooltip>
            )
          ) : (
            <Space>
              <Tooltip title={record.IsSaved ? "Bỏ lưu" : "Lưu giỏ hàng"}>
                <Button
                  size="icon-sm"
                  variant="ghost"
                  className="rounded-full"
                  onClick={async () => {
                    await userAdminApi.toggleSaveProp(record.Id);
                    mutate(propertyApi.mutateKey);
                    mutate(userAdminApi.mutateSavePropsKey);
                  }}
                >
                  <ShoppingCartIcon
                    className={
                      record.IsSaved ? "text-blue-500 fill-blue-500" : undefined
                    }
                  />
                </Button>
              </Tooltip>
              <Tooltip
                title={
                  listCompare.some((x) => x.Id === record.Id)
                    ? "Bỏ lưu"
                    : "Lưu so sánh"
                }
              >
                <Button
                  size="icon-sm"
                  variant="ghost"
                  className="rounded-full"
                  onClick={async () => {
                    onCompare({
                      Id: record.Id,
                      Image: record.MainImage
                        ? record.MainImage.Path
                        : "/home.jpg",
                      DisplayPrice: record.DisplayPrice,
                      DisplayAddress: record.PropAddress.DisplayAddress,
                    });
                  }}
                >
                  <CopyIcon
                    className={
                      listCompare.some((x) => x.Id === record.Id)
                        ? "text-blue-500 fill-blue-500"
                        : undefined
                    }
                  />
                </Button>
              </Tooltip>

              <CopyButton
                id={`btn-copy-property-${record.Id}`}
                onCopy={() => {
                  sendGTMEvent({
                    event: "copy_property",
                    value: record.Id,
                  });

                  navigator.clipboard.writeText(CopyProp(record));
                }}
              />
            </Space>
          )}
          {record.NoBroker && <Tag color="warning">Miễn trung gian</Tag>}
        </Space>
      ),
    },
  ];
};

export default columns;