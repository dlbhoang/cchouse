export interface INewsType {
  Id?: number;
  Name: string;
  NewsCount?: number;
}

export interface INewsRequest {
  Id?: number;
  NewsTypeId: number;
  Title: string;
  Summary: string;
  Content: string;
  Thumbnail: string | any[];
  Source: string;
  SourceType: string;
  Status: number;
}

export interface INewsResponse extends INewsRequest {
  StatusName: string;
  ViewCount: number;
  CreatedBy: string;
  CreatedDate: string;
  UpdatedDate: string;
  ApprovedBy?: string;
  ApprovedDate?: string;
  RejectedBy?: string;
  RejectedDate?: string;
  RejectReason?: string;
  HasPendingChanges?: boolean;
  PendingTitle?: string;
  PendingSummary?: string;
  PendingContent?: string;
  PendingThumbnail?: string;
  PendingSource?: string;
  PendingSourceType?: string;
  PendingNewsTypeId?: number;
}