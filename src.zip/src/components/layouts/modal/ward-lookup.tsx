"use client";
import { zodResolver } from "@hookform/resolvers/zod";
import { Check, ChevronDown, Copy, Loader2, MapPin, RefreshCw, ArrowLeftRight } from "lucide-react";
import Image from "next/image";
import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogClose,
  DialogFooter,
} from "@/components/ui/dialog";
import { Form } from "@/components/ui/form";
import DistrictCbxField from "@/components/ui/form-field/district-cbx";
import WardCbxField from "@/components/ui/form-field/ward-cbx";
import ProvinceCbxField from "@/components/ui/form-field/province-cbx";
import type {
  ISearchWardDto,
  IWardResponse,
} from "@/lib/interfaces/ConfigAddress/IConfigAddress";
import { cn } from "@/lib/utils";
import wardApi from "@/services/api/wardApi";
import { findWardAgencyData } from "@/data/ward-agencies";

// ─────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────
interface AgencyItem {
  name: string;
  address: string;
}
interface AgencyGroup {
  label: string;
  items: AgencyItem[];
}

// ─────────────────────────────────────────────
// Constants
// ─────────────────────────────────────────────
const AGENCY_TAGS = [
  "Văn phòng công chứng",
  "Văn phòng đất đai",
  "Chi cục thuế",
  "Ủy ban nhân dân phường",
  "Tòa án",
  "Sở tư pháp",
  "Thừa phát lại",
] as const;

const AGENCY_DROPDOWN_FIELDS = [
  "Văn phòng công chứng",
  "Văn phòng đất đai",
  "Chi cục thuế",
  "Ủy ban nhân dân phường",
  "Tòa án",
  "Sở tư pháp",
  "Thừa phát lại",
] as const;

// ─────────────────────────────────────────────
// Schema
// ─────────────────────────────────────────────
const schema = z.object({
  ProvinceId: z.coerce.number().min(1, { message: "Vui lòng chọn Tỉnh / Thành phố" }),
  DistrictId: z.coerce.number(),
  WardId: z.coerce.number().min(1, { message: "Vui lòng chọn Phường / Xã" }),
});

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────
const cbxFieldClass = [
  "[&_button]:w-full",
  "[&_button]:h-[42px]",
  "[&_button]:min-h-[42px]",
  "[&_button]:max-h-[42px]",
  "[&_button]:rounded-md",
  "[&_button]:border-0",
  "[&_button]:bg-transparent",
  "[&_button]:text-sm",
  "[&_button]:px-3",
  "[&_button]:py-0",
  "[&_button]:justify-start",
  "[&_button]:font-normal",
  "[&_button]:shadow-none",
  "[&_button]:ring-0",
  "[&_button]:focus-visible:ring-0",
  "[&_button]:focus-visible:ring-offset-0",
  "[&_button]:hover:bg-transparent",
  "[&_[role=combobox]]:w-full",
  "[&_[role=combobox]]:h-[42px]",
  "[&_[role=combobox]]:rounded-md",
  "[&_[role=combobox]]:border-0",
  "[&_[role=combobox]]:bg-transparent",
  "[&_[role=combobox]]:text-sm",
  "[&_[role=combobox]]:px-3",
  "[&_[role=combobox]]:justify-start",
  "[&_[role=combobox]]:font-normal",
  "[&_[role=combobox]]:shadow-none",
  "[&_[role=combobox]]:ring-0",
  "[&_.form-item]:m-0",
  "[&_.form-item]:p-0",
  "[&_.form-message]:hidden",
  "w-full",
].join(" ");

const selectTriggerClass =
  "w-full h-[42px] rounded-md border-0 bg-transparent text-sm shadow-none ring-0 focus:ring-0 focus-visible:ring-0 focus-visible:ring-offset-0";

/** Build agency groups from WARD_AGENCIES_MAP for a given wardId.
 *  wardName được truyền kèm để fallback tra cứu theo tên khi WardId từ
 *  backend không khớp với ID tự đánh số trong file dữ liệu tĩnh. */
function buildAgencyGroups(
  wardId: number,
  wardName: string
): AgencyGroup[] {
  const data = findWardAgencyData(wardId, wardName);
  if (!data) return [];
  return AGENCY_TAGS
    .map((tag) => {
      const key = tag as keyof typeof data.Agencies;
      const items: AgencyItem[] = (data.Agencies[key] ?? []).map((a) => ({
        name: a.name,
        address: a.address,
      }));
      return { label: tag, items };
    })
    .filter((g) => g.items.length > 0);
}

function getAgencyOptions(wardId: number, wardName: string, agencyType: string) {
  const data = findWardAgencyData(wardId, wardName);
  if (!data) return [];
  const key = agencyType as keyof typeof data.Agencies;
  return (data.Agencies[key] ?? []).map((item, index) => ({
    value: String(index),
    label: item.name,
  }));
}

// ─────────────────────────────────────────────
// FloatingField
// ─────────────────────────────────────────────
function FloatingField({
  label,
  required,
  children,
  className = "",
  error,
  filled = false,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
  className?: string;
  error?: string;
  filled?: boolean;
}) {
  const isError = !!error;
  const isFloating = filled;

  return (
    <div className={cn("flex flex-col items-start self-stretch", className)}>
      <div
        className={cn(
          "group/float relative w-full rounded-md bg-white border-2 transition-[border-color] duration-200",
          isError
            ? "border-[#EF4444]"
            : [
                "border-neutral-200 hover:border-neutral-300",
                "focus-within:border-[#0588F0]",
                "has-[button[data-state=open]]:border-[#0588F0]",
              ]
        )}
      >
        <div
          className={cn(
            "relative w-full min-h-[42px]",
            // ── ẩn toàn bộ error/message bên trong box ──
            "[&_.form-message]:hidden",
            "[&_[role=alert]]:hidden",
            "[&_.text-destructive]:hidden",
            !isFloating &&
              "[&:not(:focus-within):not(:has([data-state=open]))]:[&_button>span:first-child]:opacity-0",
            !isFloating &&
              "[&:not(:focus-within):not(:has([data-state=open]))]:[&_[data-slot=select-value]]:opacity-0"
          )}
        >
          {children}
        </div>

        <div
          className={cn(
            "absolute left-3 px-1 bg-white pointer-events-none z-10 flex items-center gap-[3px]",
            "transition-all duration-200 ease-out",
            isFloating
              ? "top-0 -translate-y-1/2 text-xs text-neutral-600"
              : "top-1/2 -translate-y-1/2 text-sm text-neutral-500",
            "group-focus-within/float:top-0 group-focus-within/float:-translate-y-1/2 group-focus-within/float:text-xs",
            "group-has-[button[data-state=open]]/float:top-0 group-has-[button[data-state=open]]/float:-translate-y-1/2 group-has-[button[data-state=open]]/float:text-xs",
            isError
              ? "text-[#EF4444] group-focus-within/float:text-[#EF4444] group-has-[button[data-state=open]]/float:text-[#EF4444]"
              : "group-focus-within/float:text-[#0588F0] group-has-[button[data-state=open]]/float:text-[#0588F0]"
          )}
        >
          <span>{label}</span>
          {required && (
            <span className="text-[#EF4444] text-[10px] leading-none">*</span>
          )}
        </div>
      </div>

      {/* ── Error bên ngoài box ── */}
      {error && (
        <span className="text-[#EF4444] text-xs mt-1 ml-1">{error}</span>
      )}
    </div>
  );
}
// ─────────────────────────────────────────────
// ToggleSwitch
// ─────────────────────────────────────────────
function ToggleSwitch({
  checked,
  onChange,
}: {
  checked: boolean;
  onChange: (checked: boolean) => void;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full transition-colors ${
        checked ? "bg-[#0588F0]" : "bg-neutral-200"
      }`}
    >
      <span
        className={`pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow-sm transition-transform ${
          checked ? "translate-x-[22px]" : "translate-x-0.5"
        }`}
      />
    </button>
  );
}

// ─────────────────────────────────────────────
// AgencyCard
// ─────────────────────────────────────────────
function AgencyCard({ group }: { group: AgencyGroup }) {
  const showMapPin = group.label !== "Chi cục thuế";

  return (
    <div className="flex flex-col items-start self-stretch py-4 px-4 gap-3 rounded-xl border border-solid border-neutral-200">
      <span className="text-neutral-950 text-base font-bold font-[family-name:var(--font-inter,Inter,sans-serif)]">{group.label}</span>
      <ul className="flex flex-col self-stretch gap-3 list-none m-0 p-0">
        {group.items.map((item, i) => (
          <li key={i} className="flex items-start self-stretch gap-3">
            <span className="text-[#0588F0] text-sm mt-0.5">•</span>
            <span className="flex-1 text-neutral-950 text-sm">
              <span className="font-semibold">{item.name}:</span> {item.address}
            </span>
            <div className="flex shrink-0 items-center gap-3">
              <button
                type="button"
                aria-label="Sao chép địa chỉ"
                className="text-neutral-400 hover:text-neutral-700 transition-colors"
                onClick={() => {
                  navigator.clipboard?.writeText(`${item.name}: ${item.address}`);
                  toast.success("Đã sao chép địa chỉ");
                }}
              >
                <Copy className="w-4 h-4" />
              </button>
              {showMapPin && (
                <button
                  type="button"
                  aria-label="Xem bản đồ"
                  className="text-neutral-400 hover:text-neutral-700 transition-colors"
                  onClick={() =>
                    window.open(
                      `https://maps.google.com/?q=${encodeURIComponent(item.address)}`,
                      "_blank"
                    )
                  }
                >
                  <MapPin className="w-4 h-4" />
                </button>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

// ─────────────────────────────────────────────
// Main dialog
// ─────────────────────────────────────────────
const WardLookupDialog = ({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) => {
  const [searchByNewAddress, setSearchByNewAddress] = useState(false);
  const [selectedAgencyTypes, setSelectedAgencyTypes] = useState<string[]>([]);
  const [agencyTypeOpen, setAgencyTypeOpen] = useState(false);
  const agencyTypeTriggerRef = useRef<HTMLButtonElement>(null);
  const [agencyTypeMenuStyle, setAgencyTypeMenuStyle] = useState<React.CSSProperties>({});
  const [wards, setWards] = useState<ISearchWardDto[]>([]);
  const [agencyGroups, setAgencyGroups] = useState<AgencyGroup[]>([]);
  const [originalAddress, setOriginalAddress] = useState<string>("");
  const dialogBodyRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!agencyTypeOpen) return;

    const updateMenuPosition = () => {
      const trigger = agencyTypeTriggerRef.current;
      if (!trigger) return;
      const rect = trigger.getBoundingClientRect();
      const dialog = dialogBodyRef.current;
      if (!dialog) return;
      const dialogRect = dialog.getBoundingClientRect();
      const viewportPadding = 8;
      const gap = 4;
      const desiredHeight = 256;
      const spaceBelow = window.innerHeight - rect.bottom - viewportPadding - gap;
      const spaceAbove = rect.top - viewportPadding - gap;
      const openAbove = spaceBelow < Math.min(desiredHeight, 180) && spaceAbove > spaceBelow;
      const availableHeight = Math.max(
        120,
        Math.min(desiredHeight, openAbove ? spaceAbove : spaceBelow)
      );
      setAgencyTypeMenuStyle({
        position: "absolute",
        left: rect.left - dialogRect.left,
        top: openAbove
          ? rect.top - dialogRect.top - availableHeight - gap
          : rect.bottom - dialogRect.top + gap,
        width: rect.width,
        maxHeight: availableHeight,
        zIndex: 100,
      });
    };

    updateMenuPosition();
    window.addEventListener("resize", updateMenuPosition);
    window.addEventListener("scroll", updateMenuPosition, true);

    return () => {
      window.removeEventListener("resize", updateMenuPosition);
      window.removeEventListener("scroll", updateMenuPosition, true);
    };
  }, [agencyTypeOpen]);

  const form = useForm<z.infer<typeof schema>>({
    resolver: zodResolver(schema),
    defaultValues: {
      ProvinceId: 1,
      DistrictId: 0,
      WardId: 0,
    },
  });

  const hasResult = wards.length > 0 || agencyGroups.length > 0;

  const filteredAgencyGroups = useMemo(() => {
    if (selectedAgencyTypes.length === 0) return [];
    return agencyGroups.filter((group) => selectedAgencyTypes.includes(group.label));
  }, [agencyGroups, selectedAgencyTypes]);

  const handleSearchModeChange = (checked: boolean) => {
    setSearchByNewAddress(checked);
    form.reset({ ProvinceId: 1, DistrictId: 0, WardId: 0 });
    setWards([]);
    setAgencyGroups([]);
    setSelectedAgencyTypes([]);
    setAgencyTypeOpen(false);
    setOriginalAddress("");
  };

  const handleReset = () => {
    form.reset({ ProvinceId: 1, DistrictId: 0, WardId: 0 });
    setWards([]);
    setAgencyGroups([]);
    setOriginalAddress("");
    setSelectedAgencyTypes([]);
    setAgencyTypeOpen(false);
    setSearchByNewAddress(false);
  };

  const handleClose = () => {
    onClose();
    handleReset();
  };

  const onSubmit = async (data: z.infer<typeof schema>) => {
    if (!searchByNewAddress && data.DistrictId < 1) {
      form.setError("DistrictId", { message: "Vui lòng chọn Quận / Huyện" });
      return;
    }

    const getLabel = (name: string) => {
      const btn = document.querySelector<HTMLElement>(`[data-field="${name}"] button`);
      return btn?.innerText?.trim() || "";
    };
    const wardLabel = getLabel("WardId");
    const districtLabel = getLabel("DistrictId");
    const provinceLabel = getLabel("ProvinceId");
    const parts = [wardLabel, districtLabel, provinceLabel].filter(Boolean);
    setOriginalAddress(parts.join(", "));

    const result = searchByNewAddress
      ? (() => {
          const newWard = findWardAgencyData(data.WardId, wardLabel);
          const mergedFromResult: ISearchWardDto[] = newWard
            ? [{
                WardId: newWard.WardId,
                WardName: newWard.WardName,
                Headquarters: newWard.UBNDAddress,
                MergedFrom: newWard.MergedFrom,
              }]
            : [];
          return { data: mergedFromResult };
        })()
      : await wardApi.getMergedTo(data.WardId);
    if (result && result.data) {
      const apiWard = (Array.isArray(result.data) ? result.data[0] : result.data) as
        | (Partial<ISearchWardDto> & Partial<IWardResponse>)
        | undefined;
      const newWard = apiWard
        ? findWardAgencyData(
            apiWard.WardId ?? apiWard.Id,
            apiWard.WardName ?? apiWard.Name
          )
        : undefined;
      const resolvedWardId = apiWard?.WardId ?? apiWard?.Id;
      const resolvedWardName = apiWard?.WardName ?? apiWard?.Name;
      const mergedResults: ISearchWardDto[] =
        resolvedWardId && resolvedWardName
          ? [{
              WardId: resolvedWardId,
              WardName: resolvedWardName,
              Headquarters: apiWard?.Headquarters ?? newWard?.UBNDAddress ?? "",
              MergedFrom: apiWard?.MergedFrom ?? newWard?.MergedFrom ?? [],
            }]
          : [];

      if (mergedResults.length === 0) {
        toast.warning("Không tìm thấy dữ liệu");
        setWards([]);
        setAgencyGroups([]);
        setSelectedAgencyTypes([]);
    setAgencyTypeOpen(false);
        return;
      }
      setWards(mergedResults);
      // Lay ID + Ten cua phuong MOI tu ket qua API, khong dung ID phuong cu tu form.
      // Ten duoc dung de fallback tra cuu neu WardId tu backend lech voi file tinh.
      const newWardId = searchByNewAddress ? data.WardId : mergedResults[0].WardId;
      const newWardName = searchByNewAddress ? wardLabel : mergedResults[0].WardName;
      setAgencyGroups(buildAgencyGroups(newWardId, newWardName));
    }
  };

  const renderAddressFields = () => (
    <>
      <FloatingField
        label="Tỉnh/Thành phố"
        required
        filled={form.watch("ProvinceId") > 0}
        className="mb-4"
        error={form.formState.errors.ProvinceId?.message}
      >
        <div className={cbxFieldClass} data-field="ProvinceId">
          <ProvinceCbxField
            name="ProvinceId"
            hiddenLabel
            placeholder=""
            popoverModal={false}
            portalContainer={dialogBodyRef}
          />
        </div>
      </FloatingField>

      {!searchByNewAddress && (
        <FloatingField
          label="Quận/Huyện"
          required
          filled={form.watch("DistrictId") > 0}
          className="mb-4"
          error={form.formState.errors.DistrictId?.message}
        >
          <div className={cbxFieldClass} data-field="DistrictId">
            <DistrictCbxField
              name="DistrictId"
              parentName="ProvinceId"
              hiddenLabel
              placeholder=""
              popoverModal={false}
              portalContainer={dialogBodyRef}
            />
          </div>
        </FloatingField>
      )}

      <FloatingField
        label="Phường/Xã"
        required
        filled={form.watch("WardId") > 0}
        className="mb-4"
        error={form.formState.errors.WardId?.message}
      >
        <div className={cbxFieldClass} data-field="WardId">
          <WardCbxField
            name="WardId"
            parentName={searchByNewAddress ? "ProvinceId" : "DistrictId"}
            isNew={searchByNewAddress}
            hiddenLabel
            placeholder=""
            popoverModal={false}
            portalContainer={dialogBodyRef}
          />
        </div>
      </FloatingField>
    </>
  );

  const renderAgencyDropdowns = () => (
    <>
      {renderAddressFields()}

      <div className="mb-2 text-sm text-neutral-500">
        Chọn loại cơ quan cần tra cứu tại phường/xã đã chọn.
      </div>

      <FloatingField
        label="Loại cơ quan"
        required
        filled={selectedAgencyTypes.length > 0}
        className="mb-4"
      >
        <div className="relative w-full">
          <button
            ref={agencyTypeTriggerRef}
            type="button"
            className="flex w-full h-[42px] items-center justify-between rounded-md bg-transparent px-3 text-sm text-neutral-950 shadow-none outline-none"
            onClick={() => setAgencyTypeOpen((open) => !open)}
            aria-expanded={agencyTypeOpen}
            aria-haspopup="listbox"
          >
            <span className={selectedAgencyTypes.length > 0 ? "truncate" : "text-neutral-500"}>
              {selectedAgencyTypes.length === 0
                ? "Chọn một hoặc nhiều loại cơ quan"
                : selectedAgencyTypes.length === 1
                  ? selectedAgencyTypes[0]
                  : `Đã chọn ${selectedAgencyTypes.length} loại cơ quan`}
            </span>
            <ChevronDown className={cn("h-4 w-4 shrink-0 text-neutral-500 transition-transform", agencyTypeOpen && "rotate-180")} />
          </button>

          {agencyTypeOpen && agencyTypeMenuStyle.left !== undefined && dialogBodyRef.current &&
            createPortal(
              <div
                style={agencyTypeMenuStyle}
                className="max-h-64 overflow-y-auto rounded-xl border border-neutral-200 bg-white p-1 shadow-lg"
                role="listbox"
                aria-multiselectable="true"
              >
                {AGENCY_DROPDOWN_FIELDS.map((field) => {
                  const checked = selectedAgencyTypes.includes(field);
                  return (
                    <button
                      key={field}
                      type="button"
                      role="option"
                      aria-selected={checked}
                      className="flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-left text-sm text-neutral-950 hover:bg-[#E8F4FE]"
                      onClick={() => {
                        setSelectedAgencyTypes((prev) =>
                          checked
                            ? prev.filter((item) => item !== field)
                            : [...prev, field]
                        );
                      }}
                    >
                      <span
                        className={cn(
                          "flex h-4 w-4 shrink-0 items-center justify-center rounded border",
                          checked
                            ? "border-[#0588F0] bg-[#0588F0] text-white"
                            : "border-neutral-300 bg-white"
                        )}
                      >
                        {checked && <Check className="h-3 w-3" />}
                      </span>
                      <span>{field}</span>
                    </button>
                  );
                })}
              </div>,
              dialogBodyRef.current
            )}
        </div>
      </FloatingField>
    </>
  );

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) handleClose(); }}>
      <DialogContent
        ref={dialogBodyRef}
        overlayClassName="bg-black/30"
        className="p-0 gap-0 w-[1152px] max-w-[calc(100vw-32px)] max-h-[calc(100dvh-32px)] flex flex-col overflow-visible rounded-xl"
      >
        <div className="flex flex-1 min-h-0 flex-col bg-white overflow-visible">

          {/* ── Header ── */}
          <div className="flex items-center self-stretch bg-white py-4 px-6 border-b border-neutral-200 rounded-tl-xl rounded-tr-xl">
            <span className="flex-1 text-neutral-950 text-lg font-bold font-[family-name:var(--font-inter,Inter,sans-serif)]">
              TRA CỨU THÔNG TIN
            </span>
          </div>

          <div className="flex flex-1 min-h-0 flex-col self-stretch bg-white px-6 pt-4 pb-6 gap-6 overflow-hidden">

            {/* ── Two-column body ── */}
            <div className="flex flex-1 min-h-0 items-stretch self-stretch gap-6 max-md:flex-col max-md:overflow-y-auto">

              {/* ── LEFT ── */}
              <div className="flex flex-1 flex-col min-w-0 min-h-0 max-md:min-h-[360px]">
                <Form {...form}>
                  <form
                    onSubmit={form.handleSubmit(onSubmit)}
                    className="flex flex-1 min-h-0 flex-col gap-4 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-neutral-300 scrollbar-track-transparent hover:scrollbar-thumb-neutral-400"
                  >
                    {/* Keep the action buttons directly after the fields. The whole form scrolls when needed. */}
                    <div className="shrink-0">
                      <div className="flex flex-col items-start self-stretch">
                        <span className="text-neutral-950 text-sm font-bold mb-4 font-[family-name:var(--font-inter,Inter,sans-serif)]">
                          Chọn khu vực, chuyển đổi phường/xã và cơ quan cần tra cứu
                        </span>

                        <div className="flex items-center justify-between self-stretch rounded-[6px] border border-[#E5E5E5] bg-[linear-gradient(90deg,_var(--Neutral-Gray-3,_#E5E5E5)_0%,_var(--Neutral-White,_#FFF)_100%)] px-4 py-3 mb-4">
                          <span className="text-neutral-950 text-sm font-[family-name:var(--font-inter,Inter,sans-serif)]">
                            Tìm theo địa chỉ mới sau sáp nhập
                          </span>
                          <ToggleSwitch
                            checked={searchByNewAddress}
                            onChange={handleSearchModeChange}
                          />
                        </div>

                        {renderAgencyDropdowns()}
                      </div>
                    </div>

                    {/* Action buttons — pinned outside the scroll area, always visible */}
                    <div className="flex items-center self-stretch gap-3 shrink-0">
                      <button
                        type="button"
                        className="flex shrink-0 items-center bg-white text-left py-2 px-6 gap-2 rounded-[10px] border border-solid border-neutral-200 hover:bg-neutral-50 transition-colors font-[family-name:var(--font-inter,Inter,sans-serif)]"
                        onClick={handleReset}
                      >
                        <RefreshCw className="w-4 h-4 text-neutral-950" />
                        <span className="text-neutral-950 text-base font-medium">Đặt lại</span>
                      </button>

                      <button
                        type="submit"
                        disabled={form.formState.isSubmitting}
                        className={`flex flex-1 justify-center items-center py-2 gap-2 rounded-[10px] border-0 transition-colors font-[family-name:var(--font-inter,Inter,sans-serif)]
                          ${form.formState.isSubmitting
                            ? "bg-[#7DC0F7] cursor-not-allowed"
                            : "bg-[#0588F0] hover:bg-[#0471CC]"
                          }`}
                      >
                        {form.formState.isSubmitting
                          ? <Loader2 className="w-4 h-4 animate-spin text-white" />
                          : <ArrowLeftRight className="w-4 h-4 text-black" />
                        }
                        <span className="text-white text-base font-medium">Tra cứu thông tin</span>
                      </button>
                    </div>
                  </form>
                </Form>
              </div>

           {/* ── RIGHT ── */}
<div className="flex flex-1 flex-col min-w-0 min-h-0">
  <span className="text-neutral-950 text-sm font-bold mb-4 font-[family-name:var(--font-inter,Inter,sans-serif)]">
    Kết quả tra cứu và chuyển đổi
  </span>

  <div
  className="
    flex-1 min-h-0 w-full overflow-y-auto pr-2
    scrollbar-thin
    scrollbar-thumb-neutral-300
    scrollbar-track-transparent
    hover:scrollbar-thumb-neutral-400
  "
>
      {!hasResult && (
      <div className="flex flex-col items-center justify-center self-stretch min-h-[280px] bg-white py-11 rounded-xl border border-solid border-neutral-200">
        <Image
          src="/icon.png"
          alt="Search icon"
          width={100}
          height={100}
          className="mb-4"
        />
        <span className="text-neutral-500 text-sm">
          Kết quả sẽ hiển thị tại đây
        </span>
      </div>
    )}

    {wards.length > 0 && (
      <>
        <h3 className="mb-3 text-sm font-bold text-neutral-950">Chuyển đổi Phường/Xã</h3>
        {wards.map((ward) => (
        <div
          key={ward.WardId}
          className="flex flex-col items-start self-stretch py-4 px-4 gap-3 rounded-xl border border-solid border-neutral-200 mb-4"
        >
          <p className="text-neutral-950 text-sm m-0">
          <span className="text-[#0588F0] mr-2">•</span>
            <span className="text-[var(--Text-Main,#0A0A0A)] font-semibold text-sm leading-[20px] font-[family-name:var(--Font-family-Text,Inter)]">
              {searchByNewAddress ? "Phường/Xã mới: " : "Phường/Quận (cũ): "}
            </span>
            <span className="text-[var(--Brand-Main,#0588F0)] font-semibold text-sm leading-[20px] font-[family-name:var(--Font-family-Text,Inter)]">
              {originalAddress || "—"}
            </span>
          </p>

          <ul className="flex flex-col gap-2 list-none m-0 p-0 pl-1">
          <li className="text-sm text-neutral-950">
              <span className="text-[#0588F0] mr-2">•</span>
              <span className="text-[var(--Text-Main,#0A0A0A)] font-semibold text-sm leading-[20px] font-[family-name:var(--Font-family-Text,Inter)]">
                  {searchByNewAddress ? "Địa chỉ cũ: " : "Sáp nhập từ: "}
              </span>
                {ward.MergedFrom.join(", ")}
            </li>
            {!searchByNewAddress && (
              <li className="text-sm text-neutral-950">
                <span className="text-[#0588F0] mr-2">•</span>
                <span className="text-[var(--Text-Main,#0A0A0A)] font-semibold text-sm leading-[20px] font-[family-name:var(--Font-family-Text,Inter)]">
                  Tên Phường / Xã mới:
                </span>{" "}
                <span className="text-[var(--Brand-Main,#0588F0)] font-semibold text-sm leading-[20px] font-[family-name:var(--Font-family-Text,Inter)]">
                  Phường {ward.WardName}, Thành phố Hồ Chí Minh
                </span>
              </li>
            )}

            
          </ul>
        </div>
        ))}
      </>
    )}

    {agencyGroups.length > 0 && (
      <div className="flex flex-col items-start self-stretch gap-4 w-full">
        {filteredAgencyGroups.length > 0 ? (
          filteredAgencyGroups.map((group) => (
            <AgencyCard
              key={group.label}
              group={group}
            />
          ))
        ) : selectedAgencyTypes.length > 0 ? (
          <div className="flex flex-col items-center self-stretch bg-white py-6 rounded-xl border border-solid border-neutral-200">
            <span className="text-neutral-500 text-sm">
              Không có dữ liệu cho loại cơ quan đã chọn.
            </span>
          </div>
        ) : null}
      </div>
    )}
  </div>
</div>
            </div>
          </div>
        </div>

        {/* ── Footer ── */}
        <DialogFooter className="flex flex-col items-end self-stretch bg-white px-6 py-4 rounded-br-xl rounded-bl-xl border-t border-neutral-200 sm:justify-end">
          <DialogClose asChild>
            <button
              type="button"
              className="flex items-center bg-white py-2 px-4 rounded-[10px] border border-solid border-neutral-200 hover:bg-neutral-50 transition-colors font-[family-name:var(--font-inter,Inter,sans-serif)]"
            >
              <span className="text-neutral-950 text-sm">Đóng</span>
            </button>
          </DialogClose>
        </DialogFooter>

      </DialogContent>
    </Dialog>
  );
};

export default WardLookupDialog;
